using System.Diagnostics;
using System.Text;
namespace RyzoriaUI.Core;
public sealed class AdbManager
{
    public string AdbPath { get; set; } = "adb";
    public async Task<string> RunAsync(string arguments)
    {
        var psi = new ProcessStartInfo { FileName=AdbPath, Arguments=arguments, RedirectStandardOutput=true, RedirectStandardError=true, UseShellExecute=false, CreateNoWindow=true, StandardOutputEncoding=Encoding.UTF8 };
        using var p = new Process { StartInfo=psi };
        p.Start();
        var output = await p.StandardOutput.ReadToEndAsync();
        var error = await p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync();
        return p.ExitCode == 0 ? output.Trim() : error.Trim();
    }
    public async Task<bool> AvailableAsync() { try { return (await RunAsync("version")).Contains("Android Debug Bridge", StringComparison.OrdinalIgnoreCase); } catch { return false; } }
    public async Task<string[]> DevicesAsync()
    {
        var text=await RunAsync("devices");
        return text.Split('\n',StringSplitOptions.RemoveEmptyEntries).Skip(1).Where(x=>x.TrimEnd().EndsWith("device",StringComparison.OrdinalIgnoreCase)).Select(x=>x.Split('\t')[0]).ToArray();
    }
    public Task<string> PropAsync(string serial,string prop)=>RunAsync($"-s {serial} shell getprop {prop}");
    public Task<string> BatteryAsync(string serial)=>RunAsync($"-s {serial} shell dumpsys battery");
    public Task<string> ResolutionAsync(string serial)=>RunAsync($"-s {serial} shell wm size");
    public Task<string> LockAsync(string serial)=>RunAsync($"-s {serial} shell input keyevent 26");
    public Task<string> HomeAsync(string serial)=>RunAsync($"-s {serial} shell input keyevent 3");
    public Task<string> BackAsync(string serial)=>RunAsync($"-s {serial} shell input keyevent 4");
}
