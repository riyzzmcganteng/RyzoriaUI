using System.Diagnostics;
namespace RyzoriaUI.Core;
public sealed class ScrcpyManager
{
    public string ScrcpyPath { get; set; } = "scrcpy";
    public Process? Start(string serial,int maxSize,int fps,int bitrate,bool fullscreen)
    {
        var psi=new ProcessStartInfo { FileName=ScrcpyPath, UseShellExecute=false, CreateNoWindow=false };
        foreach(var a in new[]{$"--serial={serial}",$"--max-size={maxSize}",$"--max-fps={fps}",$"--video-bit-rate={bitrate}M","--no-audio"}) psi.ArgumentList.Add(a);
        if(fullscreen) psi.ArgumentList.Add("--fullscreen");
        try{return Process.Start(psi);}catch{return null;}
    }
}
