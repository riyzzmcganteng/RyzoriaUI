# RyzoriaUI v1.0

Windows-only prototype Android Desktop Experience menggunakan C# WinForms + ADB + scrcpy. HP tidak perlu memasang APK RyzoriaUI.

## Target
- Windows 10/11
- Android 10+
- USB debugging
- .NET 8 SDK
- Laptop low-end: target UI ringan

## Build
1. Install .NET 8 SDK di Windows.
2. Install Android SDK Platform Tools (ADB).
3. Download scrcpy Windows dari repositori resminya.
4. Pastikan `adb.exe` dan `scrcpy.exe` ada di PATH, atau jalankan dari folder yang sama dengan executable RyzoriaUI.
5. Buka folder ini di VS Code.
6. Terminal:

```powershell
dotnet restore
dotnet build -c Release
dotnet run
```

## Cara pakai
1. Android: Settings > About Phone > tap Build Number sampai Developer Options aktif.
2. Developer Options > USB Debugging ON.
3. Sambungkan HP via USB.
4. Pilih Allow saat dialog USB debugging muncul.
5. Buka RyzoriaUI.
6. Scan Devices.
7. Pilih device.
8. Pilih resolusi/FPS/bitrate.
9. Launch Mirror.

Preset awal untuk Celeron N2040 + 4 GB: 720p / 30 FPS / 4 Mbps.

## GitHub
```bash
git init
git add .
git commit -m "RyzoriaUI v1.0 prototype"
git branch -M main
git remote add origin https://github.com/USERNAME/RyzoriaUI.git
git push -u origin main
```

Ganti USERNAME dengan akun GitHub kamu.

## Catatan
Kompatibilitas tetap bergantung pada Android, produsen, driver USB, ADB, dan kemampuan perangkat. Fitur lock screen di prototype mengirim keyevent lock; HP tetap menyala.
