using RyzoriaUI.Core;
using System.Drawing;
namespace RyzoriaUI.UI;
public sealed class MainForm:Form
{
    readonly AdbManager adb=new(); readonly ScrcpyManager scrcpy=new();
    readonly ComboBox devices=new(),res=new(),fps=new(),bitrate=new(); readonly CheckBox full=new(); readonly TextBox info=new(); readonly Label status=new();
    public MainForm(){ Text="RyzoriaUI v1.0"; StartPosition=FormStartPosition.CenterScreen; Size=new Size(1000,650); MinimumSize=new Size(820,540); BackColor=Color.FromArgb(12,16,24); ForeColor=Color.White; Font=new Font("Segoe UI",10); Build(); _=Scan(); }
    Label L(string t,int x,int y)=>new(){Text=t,AutoSize=true,Location=new Point(x,y),ForeColor=Color.Gainsboro};
    Button B(string t,int x,int y,int w,int h)=>new(){Text=t,Location=new Point(x,y),Size=new Size(w,h),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(24,34,52),ForeColor=Color.White};
    void Build(){
        var top=new Panel{Dock=DockStyle.Top,Height=72,BackColor=Color.FromArgb(18,24,36)}; top.Controls.Add(new Label{Text="RyzoriaUI",Font=new Font("Segoe UI Semibold",22),AutoSize=true,Location=new Point(24,15)}); top.Controls.Add(new Label{Text="Android Desktop Experience • v1.0",AutoSize=true,Location=new Point(190,25),ForeColor=Color.LightGray}); Controls.Add(top);
        var side=new Panel{Dock=DockStyle.Left,Width=300,BackColor=Color.FromArgb(15,20,30),Padding=new Padding(18)}; side.Controls.Add(L("DEVICE",16,10)); devices.DropDownStyle=ComboBoxStyle.DropDownList; devices.Location=new Point(16,38); devices.Width=250; side.Controls.Add(devices);
        var scan=B("↻  Scan Devices",16,82,250,38); scan.Click+=async(_,_)=>await Scan(); side.Controls.Add(scan); var launch=B("▶  Launch Mirror",16,130,250,42); launch.Click+=(_,_)=>Launch(); side.Controls.Add(launch);
        var lockb=B("🔒  Lock Phone Screen",16,180,250,38); lockb.Click+=async(_,_)=>await Lock(); side.Controls.Add(lockb);
        side.Controls.Add(L("DEVICE INFO",16,240)); info.Multiline=true; info.ReadOnly=true; info.BackColor=Color.FromArgb(9,13,20); info.ForeColor=Color.White; info.Location=new Point(16,270); info.Size=new Size(250,250); side.Controls.Add(info); Controls.Add(side);
        var main=new Panel{Dock=DockStyle.Fill,Padding=new Padding(28)}; var title=L("DISPLAY & PERFORMANCE",28,25); title.Font=new Font("Segoe UI Semibold",16); main.Controls.Add(title); Add(main,"Resolution",res,new[]{"480","640","720","900","1080"},28,75); Add(main,"FPS",fps,new[]{"15","20","30","45","60"},28,145); Add(main,"Bitrate",bitrate,new[]{"2","4","6","8","12"},28,215); res.SelectedItem="720"; fps.SelectedItem="30"; bitrate.SelectedItem="4"; full.Text="Fullscreen"; full.AutoSize=true; full.Location=new Point(28,290); main.Controls.Add(full); main.Controls.Add(new Label{Text="Recommended for Celeron N2040 + 4 GB RAM:\r\n720p • 30 FPS • 4 Mbps",AutoSize=true,Location=new Point(28,335),ForeColor=Color.LightGray}); status.Text="Status: starting..."; status.AutoSize=true; status.Location=new Point(28,425); status.ForeColor=Color.LightSkyBlue; main.Controls.Add(status); Controls.Add(main);
    }
    void Add(Control p,string name,ComboBox box,string[] values,int x,int y){p.Controls.Add(L(name,x,y)); box.DropDownStyle=ComboBoxStyle.DropDownList; box.Items.AddRange(values); box.Location=new Point(x+120,y-5); box.Width=180; p.Controls.Add(box);}
    async Task Scan(){ status.Text="Status: scanning..."; devices.Items.Clear(); if(!await adb.AvailableAsync()){status.Text="ADB not found. Install Platform Tools.";return;} var ds=await adb.DevicesAsync(); foreach(var d in ds)devices.Items.Add(d); if(ds.Length==0){status.Text="No authorized Android device.";info.Text="Enable USB debugging and authorize this PC.";return;} devices.SelectedIndex=0; await LoadInfo(ds[0]); status.Text=$"Status: {ds.Length} device(s) connected."; }
    async Task LoadInfo(string s){var m=await adb.PropAsync(s,"ro.product.model");var man=await adb.PropAsync(s,"ro.product.manufacturer");var a=await adb.PropAsync(s,"ro.build.version.release");var sdk=await adb.PropAsync(s,"ro.build.version.sdk");var d=await adb.PropAsync(s,"ro.product.device");var r=await adb.ResolutionAsync(s);info.Text=$"Manufacturer : {man}\r\nModel        : {m}\r\nDevice       : {d}\r\nAndroid      : {a}\r\nSDK          : {sdk}\r\nResolution   : {r}";}
    void Launch(){if(devices.SelectedItem is not string s){MessageBox.Show("Hubungkan HP dan izinkan USB debugging.","RyzoriaUI");return;} var p=scrcpy.Start(s,int.Parse(res.Text),int.Parse(fps.Text),int.Parse(bitrate.Text),full.Checked); status.Text=p is null?"scrcpy not found.":"scrcpy running.";}
    async Task Lock(){if(devices.SelectedItem is string s){await adb.LockAsync(s);status.Text="Phone screen locked; Android remains connected.";}}
}
